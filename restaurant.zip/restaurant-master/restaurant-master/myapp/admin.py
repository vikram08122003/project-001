

from django.contrib import admin
from .models  import booking,table


# Register your models here.
admin.site.register(booking)
admin.site.register(table)

